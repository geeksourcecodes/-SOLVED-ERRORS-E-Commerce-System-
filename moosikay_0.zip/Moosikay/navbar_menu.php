 <div class="hero-unit-table">
							
		<a href = "user_guitar.php" name = "" class = "btn btn-success">Guitar</a> 
		<a href = "user_piano.php" name = "" class = "btn btn-primary">Piano</a> 			
		<a href = "user_drums.php" name = "" class = "btn btn-info">Drums</a> 
		<a href = "user_violin.php" name = "" class = "btn btn-danger">Violin</a> 
		<a href = "user_flute.php" name = "" class = "btn btn-primary">Flute</a>
						
						
</div>