 <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a href="#"><i class="fa fa-dashboard"></i> Menu's</a>
                    </li>
                    <li>
                        <a href="product.php"><i class="fa fa-gear"></i> Products</a>
                    </li>
					<li>
                        <a href="member.php"><i class="fa fa-users"></i> Members</a>
                    </li>
					<li>
                        <a href="messages.php"><i class="fa fa-envelope"></i> Messages</a>
                    </li>
                    <li>
                        <a href="orders.php"><i class="fa fa-truck"></i> Order</a>
                    </li>
					<li>
                        <a href="user.php"><i class="fa fa-user"></i> User </a>
                    </li>
					   <li>
                        <a href="logout.php"><i class="fa fa-user"></i> Log out </a>
                    </li>


               
                 
                </ul>

            </div>

        </nav>