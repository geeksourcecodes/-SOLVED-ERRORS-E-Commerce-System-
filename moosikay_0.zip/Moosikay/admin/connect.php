<?php
	$conn = mysqli_connect("localhost", "root", "", "db_project");
	
	if(!$conn){
		die("Error: Failed to connect to database!");
	}
?>
