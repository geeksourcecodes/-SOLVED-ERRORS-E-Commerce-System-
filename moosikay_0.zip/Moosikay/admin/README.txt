Free Bootstrap Admin Template - Dream

Dream Admin is a free Bootstrap admin template. This template build on Bootstrap 3 framework along with HTML5 CSS3 and very usefull jQuery plugins to create a amazing modren admin panels, web apps, or back-end dashboards multipurpose theme. This theme is fully responsive web compatible with multi browser and devices.


Key features
-------------
Twitter Bootstrap 3.1.1
Clean & Developer-friendly HTML5 and CSS3 code
100% Responsive Layout Design 
Multipurpose Admin theme
Google Fonts Support
FontAwesome
UI Elements
Charts plugin
DataTables plugin
Smooth Scrolling 
Fully Customizable 


Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com  
=> Framework : http://getbootstrap.com
=> webthemez@gmail.com
=> Donate and remove back link in the footer

License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

 