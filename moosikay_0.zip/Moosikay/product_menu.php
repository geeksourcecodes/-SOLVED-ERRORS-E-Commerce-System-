 <div class="hero-unit-table">
							
		<a href = "guitar.php" name = "" class = "btn btn-success">Guitar</a> 
		<a href = "piano.php" name = "" class = "btn btn-primary">Piano</a> 			
		<a href = "drums.php" name = "" class = "btn btn-info">Drums</a> 
		<a href = "violin.php" name = "" class = "btn btn-danger">Violin</a> 
		<a href = "flute.php" name = "" class = "btn btn-primary">Flute</a>
						
						
</div>