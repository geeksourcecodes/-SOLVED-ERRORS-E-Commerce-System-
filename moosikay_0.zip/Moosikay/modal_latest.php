<div id="pic1" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-header">
                                    </div>
                                    <div class="modal-body">

                                        <div class="span5">

                                           <center> <img src="images/g1.png" width="200" height="200" class="img-rounded">    </center>  
                                        </div>
                                        <div class="span3">
																						
                                            
                                        </div>





                                    </div>
                                    <div class="modal-footer">
										<span><h3>GX Invaders</h3></span>
                                        <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
                                    </div>
                                </div>
<div id="pic2" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-header">
                                    </div>
                                    <div class="modal-body">

                                        <div class="span5">

                                          <center>  <img src="images/drumset.png" width="200" height="200" class="img-rounded">   </center>   
                                        </div>
                                        <div class="span3">
																						
                                            
                                        </div>





                                    </div>
                                    <div class="modal-footer">
                                        <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
                                    </div>
                                </div>
								
								
								
								
								
								
								
<div id="pic3" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-header">
                                    </div>
                                    <div class="modal-body">

                                        <div class="span5">

                                          <center>  <img src="images/piano.png" width="200" height="200" class="img-rounded">   </center>   
                                        </div>
                                        <div class="span3">
																						
                                            
                                        </div>





                                    </div>
                                    <div class="modal-footer">
                                        <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
                                    </div>
                                </div>								
								
								
														
								
								
								
<div id="pic4" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-header">
                                    </div>
                                    <div class="modal-body">

                                        <div class="span5">

                                          <center>  <img src="images/violin.png" width="200" height="200" class="img-rounded">   </center>   
                                        </div>
                                        <div class="span3">
																						
                                            
                                        </div>





                                    </div>
                                    <div class="modal-footer">
                                        <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i>&nbsp;Close</button>
                                    </div>
                                </div>								
								
								
								
								